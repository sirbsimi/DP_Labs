package Package1;

public interface Element {
    public abstract void print();
}
