#Lab DP in Java
